import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class SalvarArquivo {
    public static void main(String[] args) {
        String caminhoDoArquivo = "arquivo.txt"; // Caminho do arquivo que será salvo
        String conteudo = "Este é o conteúdo que será salvo no arquivo.";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(caminhoDoArquivo))) {
            writer.write(conteudo);
            System.out.println("Arquivo salvo com sucesso!");
        } catch (IOException e) {
            System.err.println("Ocorreu um erro ao salvar o arquivo: " + e.getMessage());
        }
    }
}
