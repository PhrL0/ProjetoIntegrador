 // Função para buscar e atualizar os dados
 function getDados() {
  // Substitua pela URL do seu endpoint Node-RED
  fetch('http://10.110.12.33:1880/cnc')
      .then(response => response.json())
      .then(data => {
          // Atualize o conteúdo da sua página com os dados recebidos
          document.getElementById('elemento').innerText = JSON.stringify(data);
          // Você pode adicionar mais lógica aqui para atualizar outros elementos
      })
      .catch(error => console.error('Erro ao buscar os dados:', error));
}

// Configura o intervalo para atualizar os dados a cada 1 segundo
setInterval(getDados, 500); // 1000 milissegundos = 1 segundo

// Chama a função uma vez ao carregar a página
window.onload = getDados;