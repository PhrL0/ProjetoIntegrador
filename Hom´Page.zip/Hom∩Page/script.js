 // Função para buscar e atualizar os dados
 function getDados() {
    // Substitua pela URL do seu endpoint Node-RED
    fetch('http://10.110.12.33:1880/cnc')
        .then(response => response.json())
        .then(data => {
            // Atualize o conteúdo da sua página com os dados recebidos
            document.getElementById('status').innerText = data.status;
            document.getElementById('x').innerText = data.x;
            document.getElementById('y').innerText = data.y;
            document.getElementById('z').innerText = data.z;
            document.getElementById('feedRate').innerText = data.feedRate;
            document.getElementById('spindle').innerText = data.spindle;
            document.getElementById('date').innerText = data.date;
            document.getElementById('time').innerText = data.time;

            switch(data.status){
                case "Idle":
                    document.getElementById('status-item').style.backgroundColor = "grey";
                case "Check":
                    document.getElementById('status-item').style.backgroundColor = "black";
                case "Run":
                    document.getElementById('status-item').style.backgroundColor = "green";
                case "Hold:0":
                    document.getElementById('status-item').style.backgroundColor = "orange";
                case "N/A":
                    document.getElementById('status-item').style.backgroundColor = "red";


            }

        })
        .catch(error => console.error('Erro ao buscar os dados:', error));

}

// Configura o intervalo para atualizar os dados a cada 0.5 segundo
setInterval(getDados, 500); // 500 milissegundos = 0.5 segundo

// Chama a função uma vez ao carregar a página
window.onload = getDados;

function startVideoFromCamera(){
    navigator.mediaDevices.getUserMedia({video:true}).then(stream=>{
        const videoElement = document.querySelector("#video")
        videoElement.srcObjetc  = stream
    }).catch(error=>{console.log(error)})
}
window.addEventListener("DOMContentLoaded",startVideoFromCamera)