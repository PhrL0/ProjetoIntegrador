import cv2
import numpy as np
import tensorflow as tf

# Carregar o modelo de classificação
modelo = tf.keras.models.load_model('keras_model.h5')

# Carregar as labels das classes
with open('labels.txt', 'r') as file:
    labels = [line.strip() for line in file.readlines()]  # Lista de labels

classes_de_interesse = ['0 faca', '1 creme']  # Adicione os nomes das classes que deseja contar
indices_classes_interesse = [labels.index(classe) for classe in classes_de_interesse]  # Obtém os índices das classes

# Função para classificar o recorte usando o modelo carregado
def classificar_objeto(imagem):
    # Pré-processamento: Redimensionamento e normalização
    imagem = cv2.resize(imagem, (224, 224))  # Ajuste para o tamanho de entrada do seu modelo
    imagem = np.expand_dims(imagem, axis=0) / 255.0  # Expande dimensões e normaliza a imagem

    # Previsão do modelo
    resultado = modelo.predict(imagem)
    classe = np.argmax(resultado)  # Obtém a classe com a maior probabilidade
    confidence_score = resultado[0][classe]
    confianca = str(np.round(confidence_score * 100))[:-2]
    print("Confidence Score:", confianca, "%")

    if int(confianca) >= 90:
        return classe  # Retorna a classe prevista
    else:
        print("Confiança baixa")
        return None

# Captura o vídeo da webcam
video = cv2.VideoCapture(0)
contador = {'contadorFaca': 0, 'contadorCreme': 0}  # Inicialização dos contadores
liberado = False

# Defina sua própria ROI aqui
x, y, w, h = 450, 100, 250, 600  # Ajuste essas coordenadas para sua área de interesse

while True:
    ret, img = video.read()
    if not ret:
        break

    img = cv2.resize(img, (1100, 720))
    imgGray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    imgTh = cv2.adaptiveThreshold(imgGray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 12)
    kernel = np.ones((8, 8), np.uint8)
    imgDil = cv2.dilate(imgTh, kernel, iterations=2)

    # Recorta a imagem para a área de interesse
    recorte = imgDil[y:y+h, x:x+w]
    brancos = cv2.countNonZero(recorte)

    # Lógica de contagem e classificação baseada na quantidade de pixels brancos
    if brancos > 1000 and liberado:
        # Recorte da imagem original para classificar o objeto
        recorte_original = img[y:y+h, x:x+w]
        classe = classificar_objeto(recorte_original)

        # Incrementa o contador apenas se a classe for a de interesse
        if classe in indices_classes_interesse:
            if classe == indices_classes_interesse[0]:  # Índice correspondente à '0 faca'
                contador['contadorFaca'] += 1
            elif classe == indices_classes_interesse[1]:  # Índice correspondente à '1 creme'
                contador['contadorCreme'] += 1

        liberado = False  # Impede contagens múltiplas
    elif brancos < 1000:
        liberado = True  # Pronto para contar novamente

    # Desenha a ROI na imagem original
    cor = (255, 0, 255) if liberado else (0, 255, 0)
    cv2.rectangle(img, (x, y), (x + w, y + h), cor, 4)

    # Exibe a contagem para a classe de interesse
    cv2.putText(img, f'Faca: {contador["contadorFaca"]}', (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
    cv2.putText(img, f'Creme: {contador["contadorCreme"]}', (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    # Mostra o vídeo com a ROI destacada e as contagens
    cv2.imshow('Video com ROI e Classificação', img)

    # Sai do loop ao pressionar 'q'
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break

# Libera os recursos
video.release()
cv2.destroyAllWindows()
