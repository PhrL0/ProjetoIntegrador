import cv2
import numpy as np

# Captura o vídeo da webcam
video = cv2.VideoCapture(0)

# Defina sua própria ROI aqui
x, y, w, h = 450, 100, 250, 600  # Ajuste essas coordenadas para sua área de interesse

while True:
    ret, img = video.read()
    if not ret:
        break

    # Redimensiona e converte a imagem para escala de cinza
    img = cv2.resize(img, (1100, 720))
    imgGray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    # Aplica um threshold adaptativo para converter para preto e branco
    imgTh = cv2.adaptiveThreshold(imgGray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 12)

    # Desenha a ROI na imagem original para visualização
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Recorta a imagem para a área de interesse e conta os pixels brancos
    recorte = imgTh[y:y + h, x:x + w]
    brancos = cv2.countNonZero(recorte)

    # Exibe a contagem de pixels brancos na tela
    cv2.putText(img, f'Pixels brancos: {brancos}', (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    # Mostra o vídeo original com a ROI e o vídeo em preto e branco
    cv2.imshow('Video Original', img)
    cv2.imshow('Video Preto e Branco', imgTh)

    # Sai do loop ao pressionar 'q'
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break

# Libera os recursos
video.release()
cv2.destroyAllWindows()
