import cv2
import numpy as np

# Captura o vídeo da webcam (índice 0 para a webcam padrão)
video = cv2.VideoCapture(0)
contador = 0
liberado = False

# Defina sua própria ROI aqui
x, y, w, h = 200, 150, 100, 200  # Ajuste essas coordenadas para sua área de interesse

while True:
    ret, img = video.read()
    if not ret:
        break  # Sai do loop se não conseguir ler o quadro

    img = cv2.resize(img, (1100, 720))
    imgGray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    imgTh = cv2.adaptiveThreshold(imgGray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 12)
    kernel = np.ones((8, 8), np.uint8)
    imgDil = cv2.dilate(imgTh, kernel, iterations=2)

    # Recorta a imagem para a área de interesse
    recorte = imgDil[y:y+h, x:x+w]
    brancos = cv2.countNonZero(recorte)

    # Lógica de contagem baseada na quantidade de pixels brancos
    if brancos > 4000 and liberado == True:
        contador += 1
        liberado = False  # Impede contagens múltiplas
    elif brancos < 4000:
        liberado = True  # Pronto para contar novamente

    # Desenha a ROI na imagem original
    if liberado:
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), 4)  # Cor magenta se pronto para contar
    else:
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 4)  # Cor verde se contando

    # Exibe a contagem de objetos
    cv2.putText(img, f'Contagem: {contador}', (x + 100, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

    # Exibe a quantidade de pixels brancos na ROI
    cv2.putText(img, str(brancos), (x-30, y-50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 1)

    # Mostra o vídeo com a ROI destacada
    cv2.imshow('Video com ROI', img)

    # Sai do loop ao pressionar 'q'
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break

# Libera os recursos
video.release()
cv2.destroyAllWindows()
