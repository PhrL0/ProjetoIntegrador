let flag = false;
// Função para buscar e atualizar os dados na página
function getDados() {
    fetch('http://10.110.12.33:1880/cnc')
        .then(response => response.json())
        .then(data => {
            // Atualize o conteúdo da sua página com os dados recebidos
            let status = data.status;
            let conexao = data.conexao;
            let x = document.getElementById('x').innerText = data.x;
            let y = document.getElementById('y').innerText = data.y;
            let z = document.getElementById('z').innerText = data.z;
            let feedRate = document.getElementById('feedRate').innerText = data.feedRate;
            let spindle = document.getElementById('spindle').innerText = data.spindle;
            let dataA = document.getElementById('data').innerText = data.dataFormatada;
            let hora = document.getElementById('hora').innerText = data.horaFormatada;

            // Atualiza a cor de fundo do status-item com base no status
            switch(status) {
                case "Idle":
                    document.getElementById('status').innerText = 'Parada'
                    document.getElementById('idle').setAttribute('fill','rgba(211, 211, 211, 1)');
                    document.getElementById('run').setAttribute('fill','grey');
                    document.getElementById('hold').setAttribute('fill','grey');
                    document.getElementById('n/a').setAttribute('fill','grey');
                    // Aqui você pode adicionar o código para piscar os LEDs, se necessário
                    break;
                case "Run":
                    document.getElementById('status').innerText = 'Funcionando';
                    document.getElementById('run').setAttribute('fill','rgba(0, 255, 0, 1)');
                    document.getElementById('idle').setAttribute('fill','grey');
                    document.getElementById('hold').setAttribute('fill','grey');
                    document.getElementById('n/a').setAttribute('fill','grey');
                    // Aqui você pode adicionar o código para piscar os LEDs, se necessário
                    break;
                case "Hold:0":
                    document.getElementById('status').innerText = 'Pausada';
                    document.getElementById('hold').setAttribute('fill','rgba(255, 165, 0, 1)');
                    document.getElementById('run').setAttribute('fill','grey');
                    document.getElementById('idle').setAttribute('fill','grey');
                    document.getElementById('n/a').setAttribute('fill','grey');
                    // Aqui você pode adicionar o código para piscar os LEDs, se necessário
                    break;
                default:
                    console.log("Ele pega desconectado")
            }
            if(conexao){
                document.getElementById('status').innerText = 'Desconectada';
                document.getElementById('n/a').setAttribute('fill','rgba(255, 0, 0, 1)');
                document.getElementById('hold').setAttribute('fill','grey');
                document.getElementById('run').setAttribute('fill','grey');
                document.getElementById('idle').setAttribute('fill','grey');
            }
            else{
                console.log("ERRO")
            }
        })
        .catch(error => console.error('Erro ao buscar os dados:', error));
}
// Função para logar dados no console
function logConsoleData() {
    fetch('http://10.110.12.33:1880/cnc')
        .then(response => response.json())
        .then(data => {
            console.log('Dados recebidos:', data); // Log de depuração
            const jsonString = JSON.stringify(data, null, 2);
            const preElement = document.createElement('pre');
            preElement.textContent = jsonString;
            const consoleContainer = document.getElementById('console');
            consoleContainer.appendChild(preElement);

            consoleContainer.scrollTop = consoleContainer.scrollHeight;
            console.log('Scroll ajustado para:', consoleContainer.scrollTop);
        })
        .catch(error => console.error('Erro ao buscar os dados:', error));
}

// Chama a função getDados a cada 100 milissegundos para atualizar os dados na página
setInterval(getDados, 100);

// Chama a função logConsoleData a cada 5 segundos para atualizar o console
setInterval(logConsoleData, 5000);

// Chama as funções uma vez ao carregar a página
window.onload = () => {
    getDados();
    logConsoleData();
};
